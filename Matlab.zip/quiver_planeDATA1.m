
clc;
close all;

filename = 'E:\data1.csv';
T = readtable(filename);  % skips selected rows of data
%T = readtable(filename, 'HeaderLines',3);  % skips selected rows of data

Bx = T.Var1';% pole = radek
By = T.Var2';
Bz = T.Var3';
x = T.Var4';
y = T.Var5';
z = T.Var6';
%No = T.Var7;neni treba

X = [0:5:100];
Y = [0:5:100]; %Y = [100:-5:0];
Z = [0:5:50];

[xxx, yyy, zzz] = meshgrid(X,Y,Z);  %4851 bodu 21x21x11

Bxxx = zeros(21,21,11);
Byyy = zeros(21,21,11);
Bzzz = zeros(21,21,11);


m =0;n=0;p=0;

for m = 0:5:100   
    
    for n = 0:5:100
        for p = 0:5:50
            
            meshIndex = find( (xxx==m)&(yyy==n)&(zzz==p) ); %pozice v 3D siti mesh
            Tindex = find( (x==m)&(y==n)&(z==p) ); %pozice v tabulce zmerenych hodnot T = c.radku v .csv
            Bxxx(meshIndex) = Bx(Tindex); %na pozici v 3D poli vloz velikost slozky Bz
            Byyy(meshIndex) = By(Tindex);
            Bzzz(meshIndex) = Bz(Tindex);
        end 
    end
end


%[U,V,W] = surfnorm(X,Y,Z);

% figure
% quiver3(X,Y,Z,U,V,W,0.5);

% hold on;
% surf(X,Y,Z);
% view(-35,45);
% axis([-2 2 -1 1 -.6 .6]);
% hold off;

%quiver3(xxx, yyy, zzz, Bxxx, Byyy, Bzzz);
hold on;
slice(xxx,yyy,zzz,Bzzz,[],[50],[]);
% [sx,sy,sz] = meshgrid(1:5:100,20:20:80,2:20:50);;%po�. bbody k�ivek (streamlines)
% streamline(xxx,yyy,zzz,Bxxx,Byyy,Bzzz,sx,sy,sz);
%streamline(X,Y,Z,U,V,W,startx,starty,startz) %draws streamlines from 3-D vector data U, V, W.
streamslice(xxx, yyy, zzz, Bxxx, Byyy, Bzzz, [], [], [25]);
box on;
axis([0 100 0 100 0 50]);
view(-30, 60);
xlabel('x [mm]');
ylabel('y [mm]');
zlabel('z [mm]');
hold off;
c = colorbar;
c.Label.String = 'Bz component [uT]';

% scatter3(xxx(:), yyy(:), zzz(:), [], B(:));
% slice(xxx,yyy,zzz,B,[],50,[]);

%B = [sqrt((Bx.^2)+(By.^2)+(Bz.^2))];  %.^ for elementwise power

