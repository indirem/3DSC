
clc;
close all;

filename = 'E:\data1.csv';
T = readtable(filename);  % skips selected rows of data
%T = readtable(filename, 'HeaderLines',3);  % skips selected rows of data

Bx = T.Var1';% pole = radek
By = T.Var2';
Bz = T.Var3';
x = T.Var4';
y = T.Var5';
z = T.Var6';
%No = T.Var7;neni treba

absB = [sqrt((Bx.^2)+(By.^2)+(Bz.^2))];  %.^ for elementwise power

X = [0:5:100];
Y = [0:5:100]; %Y = [100:-5:0];
Z = [0:5:50];

[xxx, yyy, zzz] = meshgrid(X,Y,Z);  %4851 bodu 21x21x11
[xx, yy] = meshgrid(X,Y);

Bxxx = zeros(21,21,11);
Byyy = zeros(21,21,11);
Bzzz = zeros(21,21,11);
B = zeros(21,21,11);

m =0;n=0;p=0;

%----------3D field----------------
for m = 0:5:100   
    
    for n = 0:5:100
        for p = 0:5:50
            
            meshIndex = find( (xxx==m)&(yyy==n)&(zzz==p) ); %pozice v 3D siti mesh
            Tindex = find( (x==m)&(y==n)&(z==p) ); %pozice v tabulce zmerenych hodnot T = c.radku v .csv
            Bxxx(meshIndex) = Bx(Tindex); %na pozici v 3D poli vloz velikost slozky Bz
            Byyy(meshIndex) = By(Tindex);
            Bzzz(meshIndex) = Bz(Tindex);
            %B(meshIndex) = absB(Tindex);
        end 
    end
end


%---------------quiver3--------------
%[U,V,W] = surfnorm(X,Y,Z);
% figure
%quiver3(xxx, yyy, zzz, Bxxx, Byyy, Bzzz);
% axis([0 100 0 100 0 50]);
% view(-30, 60);

% hold on;
% surf(xx,yy,Bz);
% view(-35,45);
% axis([0 100 0 100 0 50]);
% hold off;
%---------------quiver3 end--------------


%---------------slice--------------
% [x, y, z] = meshgrid(-1.5:0.1:1.5);
% u = x + cos(4*x) + 3;         % x-component of vector field
% v = sin(4*x) - sin(2*y);      % y-component of vector field
% w = -z;                       % z-component of vector field

streamslice(xxx, yyy, zzz, Bxxx, Byyy, Bzzz, [50], [], []);
box on;
axis([0 100 0 100 0 50]); %axis([-1.5 1.5 -1.5 1.5 -1.5 1.5]);
view(-30, 60);
xlabel('x [mm]');
ylabel('y [mm]');
zlabel('z [mm]');
%---------------slice end--------------


%---------------scatter--------------
% scatter3(xxx(:), yyy(:), zzz(:), [], B(:));
% slice(xxx,yyy,zzz,B,[],50,[]);
%---------------scatter end--------------

