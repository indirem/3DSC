//ver. 10.march.20

#include <Arduino.h>
#include <pins.h>
#include <LiquidCrystal.h>
#include "A4982.h"

#include <Wire.h>     //IIC to MLX90393
#include <MLX90393.h> //From https://github.com/tedyapo/arduino-MLX90393 by Theodore Yapo

#define MOTOR_STEPS 200 // steps per revolt (360°)

int pocet_mer_bodu = 0;
float tStart = 0;
float tStop = 0; 

//------------------read serial---------------//

/*Reading a serial ASCII-encoded string - looks for an ASCII string of comma-separated values ->
parses it them into ints. Created 13 Apr 2012 by Tom Igoe, modified 2020 by Li Ma
*/

const byte numChars = 32;
char receivedChars[numChars];
char tempChars[numChars];        // temporary array for use when parsing

// variables to hold the parsed serial data from Excel
char sCMD[numChars] = {0};//string command
float fResXY = 100;
float fResZ = 100;
int iNotUsed;   //not used parameter coming from excel as "0"
int iHeight; //desired scan height = distance above material to be scanned, decrease for time save
int iSense; // bool bOffset; 
uint16_t rel_X, rel_Y, rel_Z;

boolean newData = false;
bool last_Y = false;
bool last_Z = false;

//------------------END read serial-------------//


float Xco = 0;// position for PC in mm
float Yco = 0;
float Zco = 0;

int Xdir = 1; //start from autohome
int Ydir = 1;
int Zdir = 1;

long xyStep, zStep;  //motor move multipliers - long type needed 
int iNxy;  //number of steps per distance S for xy axes
int iNz;  //number of steps per distance S for z axis
float fSxy;    //distance according to XY resolution
float fSz; //..z

// int ax_lim = 2000;  //X, Y:  ca 100mm at 4 usteps per step (mode 4)
                    //(change MODE to 16 for more precision)
//int Zaxlim = 20000; //Z: ca 100mm @ mode 4

void beep()
{
    for (size_t i = 0; i < 100; i++)
    {
        digitalWrite(BEEPER, 1);
        _delay_us(250);
        digitalWrite(BEEPER, 0);
        _delay_us(50);
    }
}

bool read_button()  //check wether user press button
      { 
        bool hit = false;
        if (!(digitalRead(BTN_ENC))) 
        {
          delayMicroseconds(100);  //EM disturb?

          while (!(digitalRead(BTN_ENC))) //valid button signal, wait for relase
          
          delayMicroseconds(100);  //last few edges from relasing the button
          hit = true;
        }
        return hit;
      }

void clear_setup()
{
    //sCMD = char("0");
}

/*
//--------set max. height if user defined in excel message, default 100 mm = full
void set_height()
{
    //restrict Z move, ie number of XY planes to scan (not working yet)
}
*/

//set grid: 1,0-10,0 mm or custom one decimal float according to parameter XY Res and Z Res from Excel
void set_grid()
{       
        //r - resolution_f <10;100> * 10e(-1) [mm], compute: distance S, step number N, values of xyStep, zStep
        
        fResXY = fResXY/10; // return to <1;10> [mm] from {Res * 10e(-1) mm} format needed for trasfer without comma
        fResZ = fResZ/10;
        iNxy = int (100/fResXY); //get integer value, thus ignore decimal point of steps value
        iNz = int (iHeight/fResZ);
        fSxy = (float (iNxy)) * fResXY;  //distance to travel [mm] based on resolution multiple up to 100 mm
        fSz = (float (iNz)) * fResZ;
                
        //get uSteps needed:
        xyStep = long (fResXY * 20);  //1 mm...20 uSteps
        zStep = long (fResZ * 20) * 10;    //Z axis need ten times more uSteps (10:1 ratio)        
            
            //for test puproposes
            /*
            Serial.print(" XY Grid value from Excel ");
            Serial.println(fResXY);
            Serial.print(" Z Grid value from Excel ");
            Serial.println(fResZ);
            Serial.print(" Computed XY axes distance: ");
            Serial.println(fSxy);
            Serial.print(" Computed Z axis distance: ");
            Serial.println(fSz);
            //test print:
            Serial.print(" Test params: xyStep, zStep: ");
            //Serial.println(N);
            Serial.println(xyStep);
            Serial.println(zStep);
            //Serial.end();
            */
};

//define LCD
LiquidCrystal lcd(LCD_PINS_RS, LCD_PINS_ENABLE, LCD_PINS_D4, LCD_PINS_D5, LCD_PINS_D6, LCD_PINS_D7);

void setupLCD()
{
    // set up the LCD's number of columns and rows:
    lcd.begin(20, 4);
    lcd.clear();
};

void LCD_print(int line, const char text_string[])

{
    lcd.setCursor(0,line);
    lcd.print(text_string);
}

/*
void save_coord()
{
    Xco = (Xpos / 20);

    Yco = (Ypos / 20);

    Zco = (Zpos / 200);
}
*/
void show_coord() //current coordinates showed on LCD [mm]
{
    /*
    Serial.begin(9600);
    Serial.print(" [");
    Serial.print(Xco);
    Serial.print(",");
    Serial.print(Yco);
    Serial.print(" , ");
    Serial.print(Zco);
    Serial.print("] ");
    Serial.println();
    */
    
    lcd.clear();
    lcd.setCursor(0, 0); //1. radek
    lcd.print("Coordinates [mm]");

    lcd.setCursor(0, 1); //2. radek
    lcd.print("X: ");
    lcd.print(Xco);

    lcd.setCursor(0, 2); //3. radek
    lcd.print("Y: ");
    lcd.print(Yco);

    lcd.setCursor(0, 3); //4. radek
    lcd.print("Z: ");
    lcd.print(Zco);
}

MLX90393 mlx;        //
MLX90393::txyz data; //Create a structure, called data
                     //of four floats (t, x, y, and z)

void setup_mlx()
{
  Wire.begin();
  mlx.begin(0,0,-1); //No DRDY pin used.
  
  //------basic working settings-----------//
  mlx.setGainSel(3);
  mlx.setResolution(0, 0, 0); //x, y, z
  //------working settings-----------//

  //-------------do not delete!----------//
  mlx.setOverSampling(2);
  mlx.setDigitalFiltering(1);
  mlx.setTemperatureCompensation(0);
  mlx.setHallConf(0xC);
  mlx.readData(data); //1st read sensor - needed to inicialize
  //-------------do not delete!-----------//
        
}

//accepts: iSense from excel
void setSense(uint8_t iGainRes)
{
     uint8_t iGain, iRes_x, iRes_y, iRes_z;
     
     //set GAIN_SEL and RES
    switch (iGainRes)
    {
    
    case 0/* gain 3, res 0 */:
        iGain = 3;
        iRes_x = 0;
        iRes_y = 0;
        iRes_z = 0;
        break;
    
    case 1/* gain 7, res 0 */:
        iGain = 7;
        iRes_x = 0;
        iRes_y = 0;
        iRes_z = 0;
        break;
    
    case 2/* gain 6, res 0 */:
        iGain = 6;
        iRes_x = 0;
        iRes_y = 0;
        iRes_z = 0;
        break;
    
    case 3/* gain 5, res 1 */:
        iGain = 5;
        iRes_x = 1;
        iRes_y = 1;
        iRes_z = 1;
        break;
    
    case 4/* gain 4, res 1 */:
        iGain = 4;
        iRes_x = 1;
        iRes_y = 1;
        iRes_z = 1;
        break;

    case 5/* gain 4, res 2 */:
        iGain = 4;
        iRes_x = 2;
        iRes_y = 2;
        iRes_z = 2;
        break;
    
    case 6/* gain 3, res 2 */:
        iGain = 3;
        iRes_x = 2;
        iRes_y = 2;
        iRes_z = 2;
        break;
    
    case 7/* gain 0, res 3 */:
        iGain = 0;
        iRes_x = 3;
        iRes_y = 3;
        iRes_z = 3;
        break;

    default: /* gain 3, res 0 */
        iGain = 3;
        iRes_x = 0;
        iRes_y = 0;
        iRes_z = 0;
        break;
    }
     mlx.setGainSel(iGain);
     mlx.setResolution(iRes_x, iRes_y, iRes_z);  
}
//...................setup melexis END.................//

//.............motor objects.......................
A4982 X_stepper(MOTOR_STEPS, X_DIR_PIN, X_STEP_PIN, X_ENABLE_PIN, X_MS1, X_MS2);
A4982 Y_stepper(MOTOR_STEPS, Y_DIR_PIN, Y_STEP_PIN, Y_ENABLE_PIN, Y_MS1, Y_MS2);
A4982 Z_stepper(MOTOR_STEPS, Z_DIR_PIN, Z_STEP_PIN, Z_ENABLE_PIN, Z_MS1, Z_MS2);

void set_directions()

{
    //reset directions at material inserting position
    Xdir = 1;
    Ydir = 1;
    Zdir = 1;
}

void reset_position() //set [0,100,0] before scan begins
{
    Xco = 0;
    Yco = 100;
    Zco = 0; 
};

void setup_motor(int RPM) //motor mode (1, 2, 4, 16)
//Revolution per minute RPM setting: Scan 60 / Moving head 120
{
    X_stepper.disable();
    Y_stepper.disable();
    Z_stepper.disable();

    X_stepper.setRPM(RPM);
    X_stepper.setMicrostep(4); // step = 4 uSteps, revolutin is 800 usteps (200*4)

    Y_stepper.setRPM(RPM);
    Y_stepper.setMicrostep(4);

    Z_stepper.setRPM(RPM);
    Z_stepper.setMicrostep(4);
};

void autohome() //lowest position to insert material [0,100,Zmax]

{   
    setup_motor(120);
    X_stepper.enable();
    while (!(digitalRead(X_MIN_PIN))) //move X left till Xmin end stop
    {
        X_stepper.move(-1);
    };
    X_stepper.move(100); //start position ca 2 mm away from Xmin switch
    X_stepper.disable();

    Y_stepper.enable();
    while (!(digitalRead(Y_MAX_PIN))) //move Y up till Ymax end stop switch)
    {
        Y_stepper.move(-1);
    };
    Y_stepper.move(100); //start position away ca 2mm from Ymax switch
    Y_stepper.disable();

    Z_stepper.enable();
    while (!(digitalRead(Z_MAX_PIN)))
    {
        Z_stepper.move(-1);
    };
    Z_stepper.move(400);
    Z_stepper.disable();

    set_directions();
    setup_motor(60);
};

void moveToZmin()
    {
        //Moving to top
        Z_stepper.enable();
        while (!(digitalRead(Z_MIN_PIN)))
        {
            Z_stepper.move(1);//rise till Zmin switch is activated
        };
        Z_stepper.move(-400); //two steps down to pull Zmin switch
        Z_stepper.disable();
        Zco = 0;
        Zdir = -1;  
    };

void read_point()
{
  mlx.readData(data); //Read the values from the sensor
  
  //append X/Y/Zco coordinates for PC [mm]
  //---- format: Bx,By,Bz,X,Y,Z where X=Xco etc. -----//
    //Bx By Bz:  
    Serial.print(data.x);
    Serial.print(',');
    Serial.print(data.y);
    Serial.print(',');
    Serial.print(data.z);
    Serial.print(',');
       
    //XYZ coordinates:  
    Serial.print(Xco);
    Serial.print(",");
    Serial.print(Yco);
    Serial.print(",");
    Serial.print(Zco);
    Serial.println();
    
    //--Temperature: read once,
    //send to PC if needed, dont read during mag. field scanning to minimize time consum
    //Serial.print(data.t); 
    //delay(10); //excel reads with min 10ms period - not needed, mlx.readata() takes 20-23ms
}

//------------serial port routines-------------//
void recvWithStartEndMarkers() {
    static boolean recvInProgress = false;
    static byte ndx = 0;
    char startMarker = '<';
    char endMarker = '>';
    char rc;

    while (Serial.available() > 0 && newData == false) {
        rc = Serial.read();

        if (recvInProgress == true) {
            if (rc != endMarker) {
                receivedChars[ndx] = rc;
                ndx++;
                if (ndx >= numChars) {
                    ndx = numChars - 1;
                }
            }
            else {
                receivedChars[ndx] = '\0'; // terminate the string
                recvInProgress = false;
                ndx = 0;
                newData = true;
            }
        }

        else if (rc == startMarker) {
            recvInProgress = true;
        }
    }
}

void parseData() {      // split the data into its parts

    char * strtokIndx; // this is used by strtok() as an index

    strtokIndx = strtok(tempChars,",");      // get the first part - the string
    strcpy(sCMD, strtokIndx); // copy it to sCMD, not used
 
    strtokIndx = strtok(NULL, ","); // this continues where the previous call left off
    iHeight = atoi(strtokIndx);     // convert Height parameter to an integer

    strtokIndx = strtok(NULL, ","); // this parameter "Not used" is = 0 and saved for future command need
    iNotUsed = atoi(strtokIndx);

    //now the resolution XY and Z (floats):
    strtokIndx = strtok(NULL, ",");
    fResXY = atof(strtokIndx);

    strtokIndx = strtok(NULL, ",");
    fResZ = atof(strtokIndx);
    
    //finally the analog gain inside MLX:
    strtokIndx = strtok(NULL, ",");
    iSense = atoi(strtokIndx);
}

void showParsedData()

{
    Serial.println(" Received message: ");

    //Serial.print(" sCMD = ");
    //Serial.println(sCMD);

    Serial.print(" Height = ");
    Serial.println(iHeight);

    Serial.print(" XY Resolution = ");
    Serial.println(fResXY);
    
    Serial.print(" Z Resolution = ");
    Serial.println(fResZ);

    Serial.print(" Sensitivity = ");
    Serial.println(iSense);

}

boolean read_port()
    {
    boolean msgDone = false;
    recvWithStartEndMarkers();
    if (newData == true)
        {
            strcpy(tempChars, receivedChars);
                // this temporary copy is necessary to protect the original data
                //   because strtok() used in parseData() replaces the commas with \0
            parseData();
            showParsedData();
            newData = false;
            msgDone = true;
        }
    return msgDone;    // when msgDone = true, message is complete
}
//------------END serial port routines-------------//

void WR_parameters()

{
    //set gain/res according to MLX90393 datasheet
    setSense(iSense);
    
    //set grid based on XY and Z user values from Excel
    set_grid(); 

}

void SCAN()
{  
    show_coord();   //show start position coordinates 
    
    tStart = millis();
    
    read_point(); //MLX 1st point measurement at start position

   do //Z loop
   
    {   
        if ( (Zco == fSz) | (Zco == iHeight) ) //default (user defined) height limit reached => last XY plane  
            {
            last_Z = true;
            }   
        do  //Y loop
        {
                if ( ( (Yco == fSxy) & (Ydir==-1) )| ( (Yco == 0) & (Ydir==1) ) ) //last Y move before Z move?
                        {
                            last_Y = true;  
                        };
                do //X loop
                {                    
                    X_stepper.enable();
                    X_stepper.move(xyStep * Xdir); //direction Xdir[R:1,L:-1], ini to R
                    X_stepper.disable();
                    Xco = (Xco + (Xdir * fResXY));    //increment/decrement given by Xdir polarity
                    show_coord();
                    read_point();
                }
                while ( ( (Xco + (Xdir * fResXY)) >= 0 ) & ( (Xco + (Xdir * fResXY)) <= fSxy ) );

                //X end reached, move Y:
                Xdir = - Xdir;  //turn X direction
                
                if (!last_Y)
                {
                
                    Y_stepper.enable();
                    Y_stepper.move((xyStep * Ydir)); // Ydir[UP:-1,DOWN:1], ini to 1                               
                    Y_stepper.disable();
                    Yco = (Yco + ((-Ydir) * fResXY));
                    show_coord();
                    read_point();
                }
                
        }
        while (!last_Y);
        last_Y = false;
        //( ( (Yco + ((-Ydir) * Resolution_f)) >= 0) & ((Yco + ((-Ydir) * Resolution_f)) <= S) );
        Ydir = - Ydir;
        
        if (!last_Z)
        {
            Z_stepper.enable(); //Z_MIN = TOP END STOP SWITCH, IRQ possible, not used yet
            Z_stepper.move((zStep * Zdir)); //Zdir[UP:1,DOWN:-1], //ini to -1
            Z_stepper.disable();
            Zco = (Zco + ((-Zdir) * fResZ));
            show_coord();
            read_point();
        }
        
    }
    while (!last_Z);
    last_Z = false;    
    tStop = millis();
    //Z end reached => scan done!
    //Serial.end();
} //..................SCAN END............................//

//------------test funkce go at [X, Y] mm coordinate at z = 0 --------//
//-- X/Y from <1 to 100> integer
void Go_at(uint8_t x, uint8_t y)
{
    X_stepper.enable();
    X_stepper.move(20 * x * Xdir); //direction Xdir[R:1,L:-1], ini to R
    X_stepper.disable();

    Y_stepper.enable();
    Y_stepper.move(20 * y * Ydir); // Ydir[UP:-1,DOWN:1], ini to 1                               
    Y_stepper.disable();
}

/*
//-------------test routines-------------------//

void testXtal()
  {
      Serial.begin(9600);
      tStart = millis();
      delay(1000);
      tStop = millis();
      
      Serial.print("tStart: ");
      Serial.println(tStart);

      Serial.print("tStop: ");
      Serial.println(tStop);

      tStop = (tStop - tStart);
      Serial.println("Delay time 1000ms: ");
      Serial.print(tStop);
      Serial.println(" ms");
      Serial.end();

   } 

//--test melexis time-//
void MLX_read_time()
{
  Serial.begin(9600);
  tStart = millis();
  read_point();

  tStop = millis();
      
      Serial.print("tStart: ");
      Serial.println(tStart);

      Serial.print("tStop: ");
      Serial.println(tStop);

      tStop = (tStop - tStart);
      Serial.println("MLX read time: ");
      Serial.print(tStop);
      Serial.println(" ms");
      Serial.end();
}
//--test melexis time end----//

//--melexis time routines------//

  while(1)
  {
      while (!(read_button()));
      Serial.begin(9600);
      homing=1;    //dont handle IRQ while homing
      autohome();
      homing=0;
      reset_position();
      Go_at(10,0);
      delay(1500);
      reset_position();
      show_coord();
      delay(1500);
      tStart = millis();
      Go_at(100,0);
      tStop = millis();
      
      Serial.print("tStart: ");
      Serial.println(tStart);

      Serial.print("tStop: ");
      Serial.println(tStop);

      tStop = (tStop - tStart);
      Serial.println("time used: ");
      Serial.print(tStop);
      Serial.println(" ms");
      Serial.end();

  }
//--melexis time routines end------//

*/