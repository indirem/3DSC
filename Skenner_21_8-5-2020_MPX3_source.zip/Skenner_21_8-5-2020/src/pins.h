//pind for MPX.3 board
//from HICTOP seller of the MPX.3 board
//LCD is 20x4 (2004 type) with rotary encoder on same PCB

    #define TRIG_PIN           30 //output
    #define DRDY_PIN           57 //input, also called INT
    #define LARGE_FLASH true
    #define X_STEP_PIN         54
    #define X_DIR_PIN          55
    #define X_ENABLE_PIN       38
    #define X_MIN_PIN           3
    #define X_MAX_PIN           2
    #define X_MS1               5
    #define X_MS2               6

    #define Y_STEP_PIN         60
    #define Y_DIR_PIN          61
    #define Y_ENABLE_PIN       56
    #define Y_MIN_PIN          14
    #define Y_MAX_PIN          15
    #define Y_MS1              59
    #define Y_MS2              58

    #define Z_STEP_PIN         46
    #define Z_DIR_PIN          48
    #define Z_ENABLE_PIN       62
    #define Z_MIN_PIN          18
    #define Z_MAX_PIN          19
    #define Z_MS1              22
    #define Z_MS2              39            

    //not used for control
    #define E0_STEP_PIN        26
    #define E0_DIR_PIN         28
    #define E0_ENABLE_PIN      24

    #define LED_PIN            13
    #define FAN_PIN            -1 //was 9
    #define PS_ON_PIN          -1 //was12
    #define HEATER_1_PIN       -1
    #define TEMP_0_PIN         -1 //was 13   // ANALOG NUMBERING
    #define TEMP_1_PIN         -1 //was 15   // ANALOG NUMBERING

  //original RF100 LCD and encoder:
      #define LCD_PINS_RS 16
      #define LCD_PINS_ENABLE 17
      #define LCD_PINS_D4 23
      #define LCD_PINS_D5 25
      #define LCD_PINS_D6 27
      #define LCD_PINS_D7 29
      #define BEEPER 37
      #define BTN_EN1 31
      #define BTN_EN2 33
      #define BTN_ENC 35  //pin 55 ATMEGA, used as OK button
      #define SDCARDDETECT -1 //was 49
