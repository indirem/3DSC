//dochazi ke spousteni IRQ od Zmin, docasne deaktivovana jeho obsluha - opravit pozdeji

//beep();

#include <Arduino.h>
#include <pins.h>
#include "A4982.h"
#include <functions.h> //motor control
//#include <Wire.h>

#define DRDY 57       //pin to receive data ready signal from MLX90393
     
const char *myStrings[] = {"Press to ","begin session","(insert material)", "read from Excel",
                    "Expecting Excel data","(send Excel data)","Settings accepted", "(start recorder)",
                     "Start to scan","Scanning...", "Scan done!", "(Stop recording)", "finish", "Returning home","move home"};

const char *strErrors[] = {"X axis max reached","X axis min reached",
"Y axis max reached","Y axis min reached","Z axis max reached","Z axis min reached",
"Restart the scanner"};

bool listen = false;  //when true, loop port reading
bool msg_completed = false;
unsigned int i = 0; //test COM to PC
unsigned int j = 0;
unsigned char grid = 10;  //10mm basic step for all axis after scanner powers ON 

unsigned int homing = 0; //1 = IRQ disable when autohoming
unsigned int ErrCount = 0; //error counter

/*.......................IRQ routines.......................*/
void XmaxEnd()
  {
    delayMicroseconds(100);  //EM disturb?
    if ( (digitalRead(X_MAX_PIN)) & (!(homing)))
    {
      X_stepper.disable();
      //print "X axis max reached" error
      lcd.clear();
      LCD_print(0,strErrors[0]);
      LCD_print(1,strErrors[6]);//turn off the scanner
      while(1)
      {
        beep();
        delay(500);
      }
      ;
    }
  };

void XminEnd()
  {
    delayMicroseconds(100);  //EM disturb?
    if  ( (digitalRead(X_MIN_PIN)) & (!(homing)))
    {
      
      X_stepper.disable();
      //print "X axis min reached" error
      lcd.clear();
      LCD_print(0,strErrors[1]);
      LCD_print(1,strErrors[6]);//turn off the scanner
      beep();
      delay(500);
      //ErrCount++;
      //Serial.println(strErrors[1]);
      //Serial.println(ErrCount);
      while (!(read_button()));
      X_stepper.enable();
    }
  };

void ZminEnd()
  {
    delayMicroseconds(100);  //EM disturb?
    if  ((digitalRead(Z_MIN_PIN)) & (!(homing)))
    {
      Z_stepper.disable();
      //print "Z axis min reached" error
      lcd.clear();
      LCD_print(0,strErrors[5]);
      LCD_print(1,strErrors[6]);//turn off the scanner
    while(1)
          {
            beep();
            delay(500);
          }
    }
  };

  void ZmaxEnd()
  {
    delayMicroseconds(100);  //EM disturb?
    if  ((digitalRead(Z_MAX_PIN)) & (!(homing)))
    {
      Z_stepper.disable();
      //print "Z axis max reached" error
      lcd.clear();
      LCD_print(0,strErrors[4]);
      LCD_print(1,strErrors[6]);//turn off the scanner
    while(1)
          {
            beep();
            delay(500);
          }
    }
  };

  //NOte: Y axis end awitches not connected to external IRQ inputs on ATMEGA

  /*.......................IRQ end.......................*/

void setup()
  {
  setup_motor(60);//argument = RPM (revolutions per minute)
  setupLCD();

  pinMode(DRDY,INPUT);  //MLX 3.3V level output, for safe set as ATMEGA (TTL level) input
  pinMode(TRIG_PIN, OUTPUT);  //MLX triggerig measurements, TTL is lowered to 3,3V by added PCB level shifter
  digitalWrite(TRIG_PIN,LOW);

  pinMode(LED_PIN,OUTPUT);
  digitalWrite(LED_PIN,HIGH);
  
  pinMode(BTN_ENC,INPUT_PULLUP); //encoder button

  pinMode(X_MIN_PIN,INPUT_PULLUP);
  pinMode(Y_MAX_PIN,INPUT_PULLUP);
  pinMode(Z_MIN_PIN,INPUT_PULLUP);
  pinMode(X_MIN_PIN,INPUT_PULLUP);
  pinMode(Y_MIN_PIN,INPUT_PULLUP);
  pinMode(Z_MAX_PIN,INPUT_PULLUP);

  setup_mlx();
  
  //create IRQ (Triggered by 4 end switches. Y axis end switches not connected to IRQ inputs)
  attachInterrupt(0,XmaxEnd,RISING);
  //attachInterrupt(1,XminEnd,RISING);
  attachInterrupt(5,ZminEnd,RISING);
  attachInterrupt(4,ZmaxEnd,RISING);  
  }

void loop() 
  {

  while(1)
    {      
      //wait for button hit
      lcd.clear();
      LCD_print(0,myStrings[0]);//press to
      LCD_print(1,myStrings[1]);// begin session
      while (!(read_button()));

      //---move home---//
      lcd.clear();
      LCD_print(1,myStrings[0]);//press to
      LCD_print(2,myStrings[14]);//move home
      while (!(read_button()));
      lcd.clear();
      LCD_print(0,myStrings[13]);//returning home

      homing=1;    //dont handle IRQ while homing
      autohome();
      homing=0;    //next IRQs from endstops switches enabled
      
      //---end move home---//
      
      //while (!(read_button()));
      lcd.clear();
      LCD_print(0,myStrings[2]);//insert material
      LCD_print(1,myStrings[0]);//press to
      LCD_print(2,myStrings[3]);//read from excel
      
      while (!(read_button()))
        {
          listen=true;
        };
      
      lcd.clear();
      LCD_print(0,myStrings[4]);//Waiting for excel data...
      LCD_print(2,myStrings[5]);//(send data from excel)

      //wait for setup message from PC (resolution, offsets, other parameters)
      Serial.begin(9600);
      Serial.println("Waiting for message from Excel...");
      
      while (listen)
      {
        if (read_port()) //command received, message complete
        { 
          listen=false;
          Serial.println("Message from Excel done.");
          WR_parameters(); //set up scanner according to excel message
          Serial.end();//close serial for now

          lcd.clear();
          LCD_print(0,myStrings[6]);//accepted
          LCD_print(2,myStrings[7]);//start Data streamer recorder
          LCD_print(3,myStrings[8]);//Start to scan
        }; //message complete     
      };   //end listening from PC

      //wait for button hit to start SCANNING 
      while (!(read_button()));
      lcd.clear();
      LCD_print(0,myStrings[9]);
      beep();
      
      //-------scanner runs-----------//
      //move to start point: Z to Zmin; X,Y above the scanned area
      //and set coordinates to [0,100,0]
      homing=1;    //dont handle IRQ while moving to Zmin
      setup_motor(120);
      moveToZmin();
      reset_position();
      Go_at(10,0);
      reset_position();
      setup_motor(60);
      homing=0;    
      
      Serial.begin(9600);

      SCAN(); //scan the material and send data to PC
    
      //....SCAN done.....//
      /*
      tStop = (tStop - tStart)/1000;
      Serial.println("time used: ");
      Serial.println(tStop);
      */
      Serial.end();
      
      lcd.clear();
      beep();
      LCD_print(0,myStrings[10]);
      LCD_print(2,myStrings[11]);   
      
      homing=1;
      autohome();
      homing=0;     

      //waiting for button finish acquisition
      //lcd.clear();
      lcd.clear();
      LCD_print(2,myStrings[0]);
      LCD_print(3,myStrings[12]);
      while (!(read_button()));
      
    };//acqusition end
  
  }//main loop end


  
  //-----------test gain and res----------//
/*
  while(1)

  {
    while (!(read_button()));
    //Go_at(50,50);
    Serial.begin(9600);
    for (uint8_t n = 0; n < 1; n++)
    
    {
      setSense(n);
      
      Serial.print(" Values for Sense = ");
      Serial.print(n);
      Serial.print(" : ");
      
      read_point();
      Serial.println();
      Serial.end();
    }

    //while (!(read_button()));
    
    //autohome();

  }
  
}
//-----------END test gain and res----------//
*/  