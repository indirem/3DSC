#include <Arduino.h>
//#include <pins_MPX3.h>
//#include <functions.h>


/*
  Reading a serial ASCII-encoded string.

  This sketch demonstrates the Serial parseInt() function.
  It looks for an ASCII string of comma-separated values.
  It parses them into ints

  created 13 Apr 2012
  by Tom Igoe
  modified 18 Feb 2020
  by Li Ma
*/

// Example 5 - Receive with start- and end-markers combined with parsing

const byte numChars = 32;
char receivedChars[numChars];
char tempChars[numChars];        // temporary array for use when parsing

      // variables to hold the parsed data
char StartCMD[numChars] = {0};
int Parameter1 = 0;
float Resolution_f = 0.0;

boolean newData = false;

//"This demo expects 3 pieces of data - text, an integer and a floating point value");
//"Enter data in this style <HelloWorld, 12, 24.7>  ");

void recvWithStartEndMarkers() {
    static boolean recvInProgress = false;
    static byte ndx = 0;
    char startMarker = '<';
    char endMarker = '>';
    char rc;

    while (Serial.available() > 0 && newData == false) {
        rc = Serial.read();

        if (recvInProgress == true) {
            if (rc != endMarker) {
                receivedChars[ndx] = rc;
                ndx++;
                if (ndx >= numChars) {
                    ndx = numChars - 1;
                }
            }
            else {
                receivedChars[ndx] = '\0'; // terminate the string
                recvInProgress = false;
                ndx = 0;
                newData = true;
            }
        }

        else if (rc == startMarker) {
            recvInProgress = true;
        }
    }
}

//============

void parseData() {      // split the data into its parts

    char * strtokIndx; // this is used by strtok() as an index

    strtokIndx = strtok(tempChars,",");      // get the first part - the string
    strcpy(StartCMD, strtokIndx); // copy it to StartCMD
 
    strtokIndx = strtok(NULL, ","); // this continues where the previous call left off
    Parameter1 = atoi(strtokIndx);     // convert this part to an integer

    strtokIndx = strtok(NULL, ",");
    Resolution_f = atof(strtokIndx);     // convert this part to a float

}

//============

void showParsedData() {
    //Serial.print("Message ");
    Serial.println(StartCMD);
    //Serial.print("Integer ");
    Serial.println(Parameter1);
    //Serial.print("Float ");
    Serial.println(Resolution_f);
    
    //print_field_LCD(StartCMD, Parameter1, Resolution_f);
}

void read_port() {
    recvWithStartEndMarkers();
    if (newData == true) {
        strcpy(tempChars, receivedChars);
            // this temporary copy is necessary to protect the original data
            //   because strtok() used in parseData() replaces the commas with \0
        parseData();
        showParsedData();
        newData = false;
    }
}